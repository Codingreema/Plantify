//
//  PlantifyLine.swift
//  PlantifyLine
//
//  Created by Ahad on 14/08/1445 AH.
//

import WidgetKit
import SwiftUI
import SwiftData
import AppIntents

struct AppWidget: Widget {
    let kind: String = "AppWidget"
    
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            if #available(iOS 17.0, *) {
                AppWidgetEntryView(entry: entry)
                    .containerBackground(.fill.tertiary, for: .widget)
            } else {
                AppWidgetEntryView(entry: entry)
                    .padding()
                    .background()
            }
        }
        .configurationDisplayName("My Plants")
        .description("Take charge of your plant care routine! 🌱")
    }
}

#Preview(as: WidgetFamily.systemLarge) {
    AppWidget()
} timeline: {
    SimpleEntry(date: .now, items: [])
    SimpleEntry(date: .now, items: [
        .init(id: "0", text: "first", completedDate: nil, name: "Plant Name", plantype: "Fern", potsize: "Medium", Light: "Indirect", watering: 3)
    ])
    SimpleEntry(date: .now, items: [
        .init(id: "0", text: "first", completedDate: nil, name: "Plant Name", plantype: "Fern", potsize: "Medium", Light: "Indirect", watering: 3),
        .init(id: "0", text: "first", completedDate: nil, name: "Plant Name", plantype: "Fern", potsize: "Medium", Light: "Indirect", watering: 3)
    ])
    SimpleEntry(date: .now, items: [
        .init(id: "0", text: "first", completedDate: nil, name: "Plant Name", plantype: "Fern", potsize: "Medium", Light: "Indirect", watering: 3),
        .init(id: "0", text: "first", completedDate: nil, name: "Plant Name", plantype: "Fern", potsize: "Medium", Light: "Indirect", watering: 3),
        .init(id: "0", text: "first", completedDate: nil, name: "Plant Name", plantype: "Fern", potsize: "Medium", Light: "Indirect", watering: 3),
    ])
    SimpleEntry(date: .now, items: [])
}
