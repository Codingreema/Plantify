//
//  PlantifyLineBundle.swift
//  PlantifyLine
//
//  Created by Ahad on 14/08/1445 AH.
//

import WidgetKit
import SwiftUI

@main
struct AppWidgetBundle: WidgetBundle {
    var body: some Widget {
        AppWidget()
    }
}

