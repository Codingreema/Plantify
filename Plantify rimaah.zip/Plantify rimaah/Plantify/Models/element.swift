//
//  element.swift
//  Plantify
//
//  Created by Ahad on 15/08/1445 AH.
//


import Foundation
import SwiftData

@Model

class element {
    
    var name : String
    var plantype : String
    var potsize : String
    var Light: String
    var watering: Int
    
    // widget
    var id: String
    var text: String
    var createdDate: Date?
    var completedDate: Date?
    
    init(name: String, potsize: String, plantype: String, Light: String, watering: Int, id: String, text: String, createdDate: Date?, completedDate: Date?) {
        self.name = name
        self.plantype = plantype
        self.potsize = potsize
        self.Light = Light
        self.watering = watering
        
        // widget
        self.id = id
        self.text = text
        self.createdDate = createdDate
        self.completedDate = completedDate
    }
}

