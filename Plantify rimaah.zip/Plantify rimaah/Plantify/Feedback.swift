//
//  Feedback.swift
//  Plantify
//
//  Created by Ahad on 14/08/1445 AH.
//

import SwiftUI

struct FeedbackView: View {
    var onDone: () -> Void  // This line declares that FeedbackView accepts an 'onDone' closure.

    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack {
            Spacer()
            Image(systemName: "checkmark.circle.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 100, height: 100)
                .foregroundColor(Color.yellow)
            Text("Successfully Added!!")
                .font(.title)
                .padding()
            Spacer()
            Button("Done") {
                       onDone()  // This line calls the 'onDone' closure when the button is tapped.
                   }
            .font(.headline)
            .foregroundColor(.white)
            .frame(minWidth: 0, maxWidth: .infinity)
            .padding()
            .background(Color.green)
            .cornerRadius(10)
            .padding()
        }
    }
}


//import SwiftUI
//
//struct Feedback: View {
//    // Add this property
//    var onDone: () -> Void
//
//    var body: some View {
//        VStack {
//            Spacer()
//            
//            // Checkmark inside a circle
//            Image(systemName: "checkmark.circle.fill")
//                .resizable()
//                .scaledToFit()
//                .frame(width: 100, height: 100)
//                .foregroundColor(Color.yellow)
//            
//            // Success message
//            Text("Successfully Added!!")
//                .font(.title)
//                .padding()
//            
//            Spacer()
//            
//            // Done button
//            Button(action: {
//                // Call the closure here to perform an action when 'Done' is pressed
//                onDone()
//            }) {
//                Text("Done")
//                    .font(.headline)
//                    .foregroundColor(.white)
//                    .frame(minWidth: 0, maxWidth: .infinity)
//                    .padding()
//                    .background(Color.green)
//                    .cornerRadius(10)
//            }
//            .padding()
//        }
//    }
//}

// Preview Provider
//struct Feedback_Previews: PreviewProvider {
//    static var previews: some View {
//        // Modify the preview to provide a sample closure
//        Feedback(onDone: {})
//    }
//}

