//
//  CombineViews.swift
//  Plantify
//
//  Created by Ahad on 15/08/1445 AH.
//


// Main View here :


import SwiftUI
import SwiftData
import WidgetKit



struct CombinedContentView: View {
    @Query var itemss : [modelItems]
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.modelContext) var context
    @State private var showingFeedback = false

    // swiftdata modelItems
    @Query(sort: [SortDescriptor(\modelItems.createdDate, order: .reverse)], animation: .default)
    private var items: [modelItems]
    
    // States for UI interaction : desing
    @State private var image: Image?

    @State private var isShowingItemSheet = false
    @State private var inputText = ""
    @State private var selectedOption = 0
    let options = ["Today", "Next Week", "Overdue"]
    let customColor = Color(UIColor(red: 0/255, green: 70/255, blue: 50/255, alpha: 1))
    init() {
            UISegmentedControl.appearance().selectedSegmentTintColor = UIColor(named: "AccentColor")
        
        
        }
    

    
    var body: some View {
        NavigationStack {
            ZStack {
                VStack {
                    
                    Text("My Plants")
                        .font(.headline)
                        .fontWeight(.semibold)
                    
                    Divider()
                    
                        .frame(height: 0.33)
                        .background(Color.gray)
                        .padding(.bottom,15)
                    
                    HStack (spacing: 220){
                        
                        Text("Watering")
                            .padding(.trailing, 240)
                            .multilineTextAlignment(.leading)
                            .font(.system(size: 22))
                            .fontWeight(.bold)
                        
                        
                        
                        //
                        //                     Button("See All") {
                        //                     }
                        //                     .foregroundColor(customColor)
                        //                     .font(.system(size: 12))
                    }
                    
                    ZStack {
                    VStack {
                        Picker("", selection: $selectedOption) {
                            ForEach(0..<options.count, id: \.self) { index in
                                Text(options[index])
                                    .tag(index)
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        .padding(.horizontal) // Add horizontal padding to ensure it respects the safe area.
                        
                        if items.isEmpty{
                            VStack (spacing: 20){
                                Label("", systemImage: "zzz")
                                    .font(.system(size: 40))
                                    .foregroundColor(Color(red: 219 / 255, green: 139 / 255, blue: 0 / 255))
                                
                                Text("You don't have any plants that need watering!")
                                    .font(.system(size: 15))
                                    .foregroundColor(Color.gray)
                                
                            } .padding(.bottom,80)
                                .padding(.top,60)
                            
                        }
                        else {
                            ZStack {
                                // Background with corner radius
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundColor(.white) // Or any other background color
                                    .edgesIgnoringSafeArea(.all) // If you want the rounded rectangle to extend to all edges

                                // List
                                List {
                                    Section {
                                        ForEach(items) { item in
                                            HStack {
                                                Button {
                                                    toggleComplete(item: item)
                                                } label: {
                                                    Image(systemName: item.completedDate != nil ? "checkmark.circle.fill" : "circle")
                                                        .foregroundColor(Color(red: 219 / 255, green: 139 / 255, blue: 0 / 255)) // Change color of checkmark and circle
                                                }
                                                Text(item.text)
                                                    .listRowBackground(Color(red: 243 / 255, green: 243 / 255, blue: 243 / 255, opacity: 1)) // Set each list item's background to the new color

                                            }
//                                            .listRowInsets(EdgeInsets()) // Remove default padding
                                        }
                                        .onDelete(perform: deleteItems)
                                    }
                                    .listRowSeparatorTint(.gray)
                                }
                                .listStyle(.plain) // Use plain list style for full-width background color
                                .background(Color.white)
                            }
                            .frame(maxWidth: 350, maxHeight: .infinity) // Or specific size if needed
                            // If you need the corner radius affect the touchable area, it's more complex and requires custom implementation.
                        }


                        
                        
                    
                        
                    }
                    .padding(.bottom,30)
                    
                    
                }
                
            
                    HStack (spacing: 150){
                        Text("Office plants")
                            .font(.system(size: 27))
                            .font(.title)
                            .fontWeight(.bold)
                        
                        Button(action: {
                            isShowingItemSheet = true
                        }) {
                            Image(systemName: "plus")
                                .font(.system(size: 30))
                                .foregroundColor(Color(red: 0 / 255, green: 70 / 255, blue: 50 / 255))
                            
                        }
                        
                    }
                    .padding(.bottom,80)
                    
                    if items.isEmpty {
                        VStack (spacing: 15) {
                            
                            Image(systemName: "leaf")
                                .font(.system(size: 32))
                                .foregroundColor(Color(red: 219 / 255, green: 139 / 255, blue: 0 / 255))
                            
                            HStack { // "Tap" and "Plus" button and "to add one"
                                Text("Tap")
                                Button(action: {
                                    
                                    isShowingItemSheet = true
                                }) {
                                    Image(systemName: "plus")
                                        .font(.system(size: 17))
                                        .foregroundColor(Color(red: 0 / 255, green: 70 / 255, blue: 50 / 255))
                                }
                                Text("to add one")
                            }
                            
                            Text("You can add all plants you have in your office!")
                                .font(.system(size: 14))
                                .font(.caption)
                                .foregroundColor(Color.gray)
                                .multilineTextAlignment(.center)
                            Spacer()
                            
                        }
                    } else {
                                         ScrollView {
                                                                 LazyVStack(spacing:-40) {
                                                                     ForEach(items) { plant in
                                                                         PlantCard(plants: plant)
                                                                             .padding()
                                                                     }
                                                                 }
                                                             }
                    }}
                    Spacer()
                    
                    
                        .onChange(of: scenePhase) { newPhase in
                            if newPhase == .background {
                                WidgetCenter.shared.reloadAllTimelines() // Updates widget data
                            }
                        }
                        .toolbar {
                            ToolbarItem(placement: .navigationBarTrailing) {
                                Button(action: {
                                    isShowingItemSheet = true
                                }) {
                                    
                                }
                            }
                        }
                        .sheet(isPresented: $isShowingItemSheet) {
                            AddPlantSheet()
                        }
                }
            }
    }

    struct AddPlantSheet: View{
        @Environment (\.modelContext) var context // we can access it because we declear in schema befor
        @Environment(\.dismiss) private var dismiss
        @State private var name : String = ""
        @State private var potSize : String = ""
        @State private var plantType : String = ""
        @State private var light : String = ""
        @State private var watering : Int = 0
        @State private var wateringText: String = ""

        @State private var selectedPlant: modelItems? // Assuming this is how you manage the selected plant
        @State private var imageUploads: Data?
        @State private var imagess: Data?
        @State private var text: String = ""
        
        // array
        let plantTypes = ["Succulents", "Ferns", "Pothos", "Palm", "Peace Lilies", "Ficus"]
        let potSizes = ["4-6 inch", "6-10 inch", "10-16 inch+"]
        let lightTypes = ["Direct light", "Partial light", "No light"]
        
        
        init() {
            UISegmentedControl.appearance().selectedSegmentTintColor = UIColor(named: "AccentColor")
        }
        
        var body: some View{
            NavigationStack{
                VStack (spacing: 20){
                    // Plant name
                    Text("Plant name")
                        .font(.system(size: 17))
                        .font(.headline)
                        .fontWeight(.bold)
                        .padding(.trailing,290)
                    TextField("Coco “or app name!”", text: $text)
                        .padding(.horizontal)
                        .frame(width: 380, height: 46)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color(red: 243/255, green: 243/255, blue: 243/255, opacity: 1))
                        )
                    
//                        .padding(.bottom,90)
//                    
                    // Plant type
                    
                    VStack (spacing:30) {
                        Text("Plant Type")
                            .font(.system(size: 17))
                            .font(.headline)
                            .fontWeight(.bold)
                            .padding(.trailing,290)
                        // First row
                        LazyHGrid(rows: [GridItem(.flexible())]) {
                            ForEach(plantTypes.prefix(4), id: \.self) { type in // Adjust number based on your items per row
                                Button(action: {
                                    self.plantType = type
                                }) {
                                    Text(type)
                                        .font(.system(size: 12))
                                        .padding(8)
                                        .frame(width: 90, height: 30, alignment: .center)
                                        .background(
                                            RoundedRectangle(cornerRadius: 8)
                                                .fill(plantType == type ? Color.accentColor : Color(red: 243/255, green: 243/255, blue: 243/255, opacity: 1))
                                                .frame(width: 78, height: 46)
                                        )
                                        .foregroundColor(plantType == type ? .black : .black)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                        .padding(.bottom,20)                        // Second row
                        LazyHGrid(rows: [GridItem(.flexible())]) {
                            ForEach(plantTypes.suffix(2), id: \.self) { type in // Adjust this to capture the last two items
                                Button(action: {
                                    self.plantType = type
                                }) {
                                    Text(type)
                                        .font(.system(size: 12))
                                        .padding(8)
                                        .frame(width: 90, height: 30, alignment: .center)
                                        .background(
                                            RoundedRectangle(cornerRadius: 8)
                                                .fill(plantType == type ? Color.accentColor : Color(red: 243/255, green: 243/255, blue: 243/255, opacity: 1))
                                                .frame(width: 78, height: 46)
                                            
                                        )
                                        .foregroundColor(plantType == type ? .black : .black)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                    }
               
                        // Pot Sizes Section
                        Text("Pot Size")
                            .font(.system(size: 17))
                            .font(.headline)
                            .fontWeight(.bold)
                            .padding(.trailing,290)
                        
                        LazyHGrid(rows: [GridItem(.flexible())]) {
                            ForEach(potSizes, id: \.self) { size in
                                Button(action: {
                                    self.potSize = size
                                }) {
                                    Text(size)
                                        .font(.system(size: 12))
                                        .padding(8)
                                        .frame(width: 90, height: 30, alignment: .center)
                                        .background(
                                            RoundedRectangle(cornerRadius: 8)
                                                .fill(potSize == size ? Color.accentColor : Color(red: 243/255, green: 243/255, blue: 243/255, opacity: 1))
                                                .frame(width: 78, height: 46)
                                            
                                        )
                                        .foregroundColor(potSize == size ? .white : .black)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                    
                    
                    // Light Requirements Section
                    Text("Light")
                        .font(.system(size: 17))
                        .font(.headline)
                        .fontWeight(.bold)
                        .padding(.trailing,290)
                    LazyHGrid(rows: [GridItem(.flexible())]) {
                        ForEach(lightTypes, id: \.self) { lightType in
                            Button(action: {
                                self.light = lightType
                            }) {
                                Text(lightType)
                                    .font(.system(size: 12))
                                    .padding(8)
                                    .frame(width: 90, height: 30, alignment: .center)
                                    .background(
                                        RoundedRectangle(cornerRadius: 8)
                                            .fill(light == lightType ?  Color.accentColor : Color(red: 243/255, green: 243/255, blue: 243/255, opacity: 1))
                                            .frame(width: 78, height: 46)
                                    )
                                    .foregroundColor(light == lightType ? .white : .black)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                    HStack {
                        Text("Watering")
                            .padding(.leading, 10) // Add padding on the left side for spacing

                        Spacer() // Use spacer to push content to the sides

                        TextField("0", value: $watering, formatter: NumberFormatter())
                            .keyboardType(.numberPad)
                            .frame(width: 40) // Adjust width as needed
                            .multilineTextAlignment(.center) // Center the text inside the TextField
                            .onChange(of: watering) { newValue in
                                watering = min(max(newValue, 1), 7) // Ensure watering stays within 1...7
                            }


                        Text("/ week")
                            .padding(.trailing, 10) // Add padding on the right side for spacing
                    }
                    .frame(width: 380, height: 46) // Set the overall frame for the HStack
                    .background(
                        RoundedRectangle(cornerRadius: 10) // Set rounded corners for the background
                            .fill(Color(red: 243/255, green: 243/255, blue: 243/255, opacity: 1))
                    )
                    .padding(.top,70)

                    

                }
                .padding(.bottom,130)
            

                
                .navigationBarTitle("Add Office Plant")
                .navigationBarTitleDisplayMode(.inline) // Set the title display mode to inline, which centers the title for iOS 14+

                .toolbar{
                    ToolbarItemGroup(placement:.topBarLeading){
                        Button("Cancel"){dismiss()}
                    }
                    ToolbarItemGroup(placement:.topBarTrailing){
                        Button("Add"){
                            let plant = modelItems(
                                id: UUID().uuidString,
                                text: text,
                                createdDate: Date(),
                                completedDate: nil,
                                name: name,
                                potsize: potSize,
                                plantype: plantType,
                                Light: light,
                                watering: watering,
                                imageUpload: imageUploads,
                                images: Data(),
                                dataImg: Data()
                            
                            )
                            context.insert(plant)
                            dismiss()
                        }
                        Spacer()
                    }
                    
                }



//
//                    
//                    Section(header: Text("Pot Size")) {
//                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 50), spacing: 40)], spacing: 10) {
//                            ForEach(potSizes, id: \.self) { size in
//                                Button(action: {
//                                    self.potSize = size
//                                }) {
//                                    Text(size)
//                                        .font(.system(size: 12)) // Reduced text size
//                                        .padding(8)
//                                        .frame(width: 100, height: 40) // Adjusted frame size
//                                        .background(
//                                            RoundedRectangle(cornerRadius: 8)
//                                                .foregroundColor(potSize == size ? Color.accentColor : Color.white)
//                                        )
//                                }
//                                .buttonStyle(PlainButtonStyle())
//                            }
//                        }
//                    }
//                    
//                    Section(header: Text("Light")) {
//                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 50), spacing: 40)], spacing: 10) {
//                            ForEach(lightTypes, id: \.self) { light in
//                                Button(action: {
//                                    self.light = light
//                                }) {
//                                    Text(light)
//                                        .font(.system(size: 12)) // Reduced text size
//                                        .padding(8)
//                                        .frame(width: 100, height: 40) // Adjusted frame size
//                                        .background(
//                                            RoundedRectangle(cornerRadius: 8)
//                                                .foregroundColor(self.light == light ? Color.accentColor : Color.white)
//                                        )
//                                }
//                                .buttonStyle(PlainButtonStyle())
//                            }
//                        }
//                    }
                    
//                    //WATERING
//                    HStack {
//                        Text("Watering")
//                        Spacer() // Add spacer to push TextField to the end
//                        
//                        TextField("0", value: $watering, formatter: NumberFormatter())
//                            .keyboardType(.numberPad)
//                            .frame(width: 40) // Adjust width as needed
//                            .onChange(of: watering) { newValue in
//                                if !(1...7).contains(newValue) {
//                                }
//                                watering = watering
//                            }
//                        Text("/ week")
//                        
//                    }
                    
                    
                    //                Text("Watering")
                    //                TextField("0", text: Binding<String>(
                    //                    get: {
                    //                        "\(Watering)/ week"
                    //
                    //                }, set: { newValue in
                    //                    if let intValue = Int(newValue), (1...7).contains(intValue) {
                    //                        Watering = intValue
                    //                    } else {
                    //                        print("only 7")
                    //                    }
                    //                }))
                }
//                .navigationBarTitle("Add Office Plant") // Set navigation title dynamically to plant name
//                .toolbar{
//                    ToolbarItemGroup(placement:.topBarLeading){
//                        Button("Cancel"){dismiss()}
//                    } 
//                    ToolbarItemGroup(placement:.topBarTrailing){
//                        Button("Add"){
//                            let plant = modelItems(
//                                id: UUID().uuidString,
//                                text: text,
//                                createdDate: Date(),
//                                completedDate: nil,
//                                name: name,
//                                potsize: potSize,
//                                plantype: plantType,
//                                Light: light,
//                                watering: watering,
//                                imageUpload: imageUploads,
//                                images: imagess
//                            
//                            )
//                            context.insert(plant)
//                            dismiss()
//                        }
//                    }
//                    
//                }
//            }.background(.red)
            
        }
        
    }

    
    
//    struct AddItemSheet: View {
//        var context: ModelContext  // Just a regular variable, not an @Environment : for modelllllllll swiftdataaaa
//        @Binding var inputText: String
//
//        @Environment(\.dismiss) var dismiss
//
//        @State private var text: String = ""
//        
//        // for our modelitem we neeedddd 😫😫
//        @State private var name: String = ""
//        @State private var potSize: String = ""
//        @State private var plantType: String = ""
//        @State private var lightCondition: String = ""
//        @State private var wateringFrequency: Int = 0
//        @State private var imageUploads: Data?
//        var body: some View {
//            NavigationView {
//                Form {
//                    // names for add textfield and we can design it as we want 😊
//
//                    TextField("Plant Name", text: $text)
//                    TextField("Plant Type", text: $plantType)
//                    TextField("Pot Size", text: $potSize)
//                    TextField("Light Condition", text: $lightCondition)
//                    TextField("Watering Frequency", value: $wateringFrequency, format: .number)
//                }
//                .navigationTitle("Add Office Plant")
//                .toolbar {
//                    ToolbarItem(placement: .navigationBarLeading) {
//                        Button("Cancel")
//                        {
//                            dismiss()
//                        }
//                    }
//                    ToolbarItem(placement: .navigationBarTrailing) {
//                        Button("Add")
//                        {
//                            let newItem = modelItems(
//                                id: UUID().uuidString,
//                                text: text,
//                                createdDate: Date(),
//                                completedDate: nil,
//                                name: name,
//                                potsize: potSize,
//                                plantype: plantType,
//                                Light: lightCondition,
//                                watering: wateringFrequency, 
//                                imageUpload: imageUploads
//                            )
//                            context.insert(newItem)
//                            dismiss()
//                        }
//                    }
//                }
//            }
//        }
//    }

    private func toggleComplete(item: modelItems) {
        withAnimation {
            
            if item.completedDate == nil {
                item.completedDate = .now
                
            } else {
                item.completedDate = nil
            }
         
        }
        
        WidgetCenter.shared.reloadAllTimelines()
    }
    
    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            for index in offsets {
                context.delete(items[index])
            }
        }
        // widget contact 🥳
        WidgetCenter.shared.reloadAllTimelines()
    }
}

#Preview {
    CombinedContentView()
}

