//
//  ContentView.swift
//  Plantify
//
//  Created by Ahad on 14/08/1445 AH.
//
//
//import SwiftUI
//import SwiftData
//
//struct ContentView: View {
//   
//    @Query var elements : [element] // @Query to fetch the element 
//    
//    @State private var expenseToEdit: element? // used to track the element selected for editing.
//    @Environment(\.modelContext) var context // Accesses the environment's modelContext, typically used for database operations in a SwiftUI app.
//    @State private var isShowingItemSheet = false // A private state variable that determines whether the AddExpenseSheet modal is displayed.
//
//    var body: some View { // The main view body.
//        NavigationStack { // A navigation view that enables a hierarchical navigation interface.
//            List { // A list that displays rows of data.
//                ForEach(elements) { element in // Loops through each 'element' in 'elements'.
//                    ExpenseCell(elements: element) // Creates a cell for each element.
//                        .onTapGesture { // Adds an action for when the cell is tapped.
//                          expenseToEdit = element // Sets the tapped element as the one to edit.
//                        }
//                }
//                .onDelete { indexSet in // Allows deleting of elements from the list.
//                    for index in indexSet {
//                        context.delete(elements[index]) // Deletes the selected element from the context.
//                    }
//                }
//            }
//            .navigationTitle("My Plants") // Sets the title for the navigation bar.
//            .sheet(isPresented: $isShowingItemSheet) { AddExpenseSheet() } // Presents the AddExpenseSheet when isShowingItemSheet is true.
//            .sheet(item: $expenseToEdit) { elements in // Presents the UpdateExpenseSheet when an item is set to be edited.
//                UpdateExpenseSheet(elements: elements)
//            }
//            .toolbar { // Adds items to the toolbar.
//                if !elements.isEmpty { // Checks if there are any elements.
//                    Button("Add elements", systemImage: "plus") { // Adds a button to add new elements.
//                        isShowingItemSheet = true // Shows the AddExpenseSheet when the button is clicked.
//                    }
//                }
//            }.overlay { // Adds an overlay to the list.
//                if elements.isEmpty { // Checks if there are no elements.
//                    ContentUnavailableView(label: { // Displays a custom view when no elements are available.
//                        Label("No Plants here", systemImage: "list.bullet.rectangle.portrait")
//                    }, description: {
//                        Text("Start adding plants to see your List.") // Provides a description.
//                    }, actions: {
//                        Button("Adding Plants") { isShowingItemSheet = true } // Provides an action button to add plants.
//                    }).offset(y: -60) // Moves the overlay up a bit.
//                }
//            }
//        }
//    }
//}
//
//#Preview {
//    ContentView()
//}
//
//struct ExpenseCell: View { // Defines a new struct for the cell view in the list.
//    
//    let elements: element // Defines a constant 'elements' of type 'element'.
//    var body: some View { // The body of the cell view.
//        HStack { // A horizontal stack.
//             Text(elements.name) // Displays the name of the element.
//            Spacer() // Pushes the text to the left.
//        }
//    }
//}
//
//struct AddExpenseSheet: View { // Defines a new struct for adding a new element.
//    @Environment(\.modelContext) var context // Accesses the environment's modelContext for database operations.
//    @Environment(\.dismiss) private var dismiss // The mechanism to dismiss the view.
//    @State private var name: String = "" // State variables for user input.
//    @State private var PotSize: String = ""
//    @State private var PlantType: String = ""
//    @State private var Light: String = ""
//    @State private var Watering: Int = 1 // A numeric state variable for watering frequency.
//
//    // Below are definitions for form inputs and selections.
//    @State private var inputText = ""
//    let plantTypes = ["Succulents", "Ferns", "Pothos", "Palm", "Peace Lilies", "Ficus"] // Array of plant types for the picker.
//    let potSizes = ["4-6 inch", "6-10 inch", "10-16 inch+"] // Array of pot sizes for the picker.
//    let lightTypes = ["Direct light", "Partial light", "No light"] // Array of light types for the picker.
//    
//    var body: some View { // The body of the add sheet view.
//        NavigationStack { // A navigation view.
//            Form { // A form for user inputs.
//                Section {
//                    TextField("Plant name", text: $name) // Text field for entering the plant name.
//                }
//                // Below are sections for picking plant type, pot size, and light type.
//                Section {
//                    Picker("Plant Type", selection: $PlantType) {
//                        ForEach(plantTypes, id: \.self) { type in
//                            Text(type)
//                        }
//                    }
//                }
//                Section {
//                    Picker("Pot size", selection: $PotSize) {
//                        ForEach(potSizes, id: \.self) { size in
//                            Text(size)
//                        }
//                    }
//                }
//                Section {
//                    Picker("Lights", selection: $Light) {
//                        ForEach(lightTypes, id: \.self) { type in
//                            Text(type)
//                        }
//                    }
//                }
//                // Section for watering frequency.
//                Text("Watering")
//                TextField("0", text: Binding<String>(
//                    get: {
//                        "\(Watering)/ week"
//                }, set: { newValue in
//                    if let intValue = Int(newValue), (1...7).contains(intValue) {
//                        Watering = intValue // Updates the watering frequency based on input.
//                    } else {
//                        print("only 7") // Prints an error message if the input is invalid.
//                    }
//                }))
//            }
//            .navigationTitle("New elements") // Sets the title for the navigation bar.
//            .toolbar { // Adds items to the toolbar.
//                ToolbarItemGroup(placement: .topBarLeading) {
//                    Button("Cancel") { dismiss() } // A button to cancel the action and close the sheet.
//                }
//                ToolbarItemGroup(placement: .topBarTrailing) {
//                    Button("Save") { // A button to save the new element.
//                        let element = element(name: name, potsize: PotSize, plantype: PlantType, Light: Light, watering: Watering, id: UUID().uuidString, text: inputText, createdDate: Date(), completedDate: nil) // Creates a new element with the provided information.
//                        context.insert(element) // Inserts the new element into the context.
//                        dismiss() // Closes the sheet.
//                    }
//                }
//            }
//        }.background(.red) // Sets the background color of the navigation stack.
//    }
//}
//
//struct UpdateExpenseSheet: View { // Defines a new struct for updating an existing element.
//    @Environment(\.dismiss) private var dismiss // The mechanism to dismiss the view.
//    @Bindable var elements: element // A bindable property to hold the element being edited.
//    
//    var body: some View { // The body of the update sheet view.
//        NavigationStack { // A navigation view.
//            Form { // A form for editing the element.
//                TextField("Expense Name", text: $elements.name) // A text field for editing the name of the element.
//            }
//            .navigationTitle("Update Elements") // Sets the title for the navigation bar.
//            .toolbar { // Adds items to the toolbar.
//                ToolbarItemGroup(placement: .topBarLeading) {
//                    Button("Done") { dismiss() } // A button to finish editing and close the sheet.
//                }
//            }
//        }
//    }
//}

