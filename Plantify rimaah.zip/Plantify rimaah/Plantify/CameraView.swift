//
//  CameraView.swift
//  Plantify
//
//  Created by Rimah on 15/08/1445 AH.
//
//

import SwiftUI
import AVFoundation

struct CameraView: UIViewControllerRepresentable {
    @Binding var isShown: Bool
    @Binding var image: Image?
    var onImageCaptured: () -> Void

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            picker.sourceType = .camera
        } else {
            picker.sourceType = .photoLibrary
        }
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        var parent: CameraView

        init(_ parent: CameraView) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
                parent.image = Image(uiImage: uiImage)
                parent.onImageCaptured()
            }
            parent.isShown = false
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.isShown = false
        }
    }
}


//import SwiftUI
//import AVFoundation // Needed for camera access
//
//// CameraView that conforms to UIViewControllerRepresentable
//struct CameraView: UIViewControllerRepresentable {
//    @Binding var isShown: Bool
//    @Binding var image: Image?
//    var onImageCaptured: () -> Void
//
//    func makeUIViewController(context: Context) -> UIImagePickerController {
//        let picker = UIImagePickerController()
//        if UIImagePickerController.isSourceTypeAvailable(.camera) {
//            picker.delegate = context.coordinator
//            picker.sourceType = .camera
//        } else {
//            // If the camera is not available (like in a simulator), use the photo library instead
//            picker.sourceType = .photoLibrary
//        }
//        return picker
//    }
//
//    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
//
//    func makeCoordinator() -> Coordinator {
//        Coordinator(self, onImageCaptured: onImageCaptured)
//    }
//
//    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
//        let parent: CameraView
//        let onImageCaptured: () -> Void
//
//        init(_ parent: CameraView, onImageCaptured: @escaping () -> Void) {
//            self.parent = parent
//            self.onImageCaptured = onImageCaptured
//        }
//
//        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
//            if let uiImage = info[.originalImage] as? UIImage {
//                parent.image = Image(uiImage: uiImage)
//                parent.isShown = false // Dismisses the camera view
//                parent.onImageCaptured() // Triggers the feedback view in the parent
//            }
//        }
//
//        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
//            parent.isShown = false
//        }
//    }
//}
