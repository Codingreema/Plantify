//
//  PlantCard.swift
//  Plantify
//
//  Created by Rimah on 15/08/1445 AH.
//
import SwiftUI

struct PlantCard: View {
    let plants: modelItems  // This is correct: 'plants' is an instance of 'modelItems'

    var body: some View {
        NavigationLink(destination: PlantInfoSheet(QuoteConfig: dumbQuote , plants: plants, images: [])) {

            RoundedRectangle(cornerRadius: 10)
                .fill(Color.gray.opacity(0.2))
                .frame(width: 350, height: 150)
                .padding()
                .overlay(
                    HStack{
                        Image("plant33")
                            .resizable()
                            .frame(width: 100, height: 100)
                            .padding()
                        VStack(alignment: .leading, spacing: 10) {
                            
                            Text(plants.text)
                                .font(.headline)
                                .padding(.leading, 10) // Add padding to the left
                                .foregroundColor(Color.black) // Set text color to black
                            Text("Type: \(plants.plantype)")
                                .font(.subheadline)
                                .padding(.leading, 10) // Add padding to the left
                                .padding(.trailing, 10) // Add padding to the right
                                .foregroundColor(Color.black) // Set text color to black
                            Text("Pot Size: \(plants.potsize)")
                                .font(.subheadline)
                                .padding(.leading, 10) // Add padding to the left
                                .padding(.trailing, 10) // Add padding to the right
                                .foregroundColor(Color.black) // Set text color to black
                            Text("Light: \(plants.Light)")
                                .font(.subheadline)
                                .padding(.leading, 10) // Add padding to the left
                                .padding(.trailing, 10) // Add padding to the right
                                .foregroundColor(Color.black) // Set text color to black
                            Text("Watering: \(plants.watering)/week")
                                .font(.subheadline)
                                .padding(.leading, 10) // Add padding to the left
                                .padding(.trailing, 10) // Add padding to the right
                                .foregroundColor(Color.black) // Set text color to black
                        }
                    }
                        
                        .cornerRadius(8)
                        .padding()
                    , alignment: .topLeading
                )
        }
    }
}
